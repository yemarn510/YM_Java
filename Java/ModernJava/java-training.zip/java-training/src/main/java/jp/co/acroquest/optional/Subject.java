package jp.co.acroquest.optional;

public enum Subject {
    MATHEMATICS,
    HISTORY,
    SCIENCE
}
