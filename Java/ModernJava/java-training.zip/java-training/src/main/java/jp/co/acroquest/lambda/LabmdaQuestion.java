package jp.co.acroquest.lambda;

import java.util.function.*;

/**
 * Answer following questions.
 *
 * @see <a href="https://www.baeldung.com/java-8-functional-interfaces">Baeldung.com - Functional Interfaces in Java 8</a>
 */
public class LabmdaQuestion {

    /**
     * Question 1:
     * <pre>
     *     Return function to convert strings to upper case by using a labmda expression.
     * </pre>
     *
     * @return
     */
    public Function<String, String> mapToUpperCase() {
        return null;
    }

    /**
     * Question 2:
     * <pre>
     *     Return function to create FullName by given string.
     *     Example: "John Do" -> FullName(firstName: "John", lastName: "Do")
     * </pre>
     *
     * @return
     */
    public Function<String, FullName> convertToFullName() {
        return null;
    }

    /**
     * Question 3:
     * <pre>
     *     Return function to get max int value.
     * </pre>
     *
     * @return
     */
    public BiFunction<Integer, Integer, Integer> max() {
        return null;
    }

    /**
     * Question 4:
     * <pre>
     *
     * </pre>
     *
     * @return
     */
    public Supplier<RuntimeException> runtimeExceptionSupplier() {
        return null;
    }

    /**
     * Question 5:
     * <pre>
     *      Return function to print givn strings. (Use System.out.println())
     * </pre>
     *
     * @return
     */
    public Consumer<String> printConsumer() {
        return null;
    }

    /**
     * Question 6:
     * <pre>
     *     Return function to check given int value is greater than 30.
     * </pre>
     *
     * @return
     */
    public Predicate<Integer> checkOver30() {
        return null;
    }

}
