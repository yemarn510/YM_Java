package jp.co.acroquest.stream;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Answer following questions.<BR>
 * Caution: Do NOT use for statements.
 *
 * @see <a href="https://www.baeldung.com/java-streams">Baeldung.com - Java Streams</a>
 */
public class StreamQuestion {

    /**
     * Question 1:
     * <pre>
     *      Create a stream by given list.
     * </pre>
     *
     * @param list
     * @return
     */
    public Stream<String> createStream(List<String> list) {
        return null;
    }

    /**
     * Question 2:
     * <pre>
     *     Create a stream from given array.
     * </pre>
     *
     * @param strings
     * @return
     */
    public Stream<String> createStreamFromArray(String[] strings) {
        return null;
    }

    /**
     * Question 3:
     * <pre>
     *     Convert given stream to java.util.Set.
     * </pre>
     *
     * @param dateStream
     * @return
     */
    public Set<LocalDate> streamToSet(Stream<LocalDate> dateStream) {
        return null;
    }

    /**
     * Question 4:
     * <pre>
     *     Join given 2 streams.
     * </pre>
     *
     * @param stream1
     * @param stream2
     * @return
     */
    public Stream<LocalDate> joinStreams(Stream<LocalDate> stream1, Stream<LocalDate> stream2) {
        return null;
    }

    /**
     * Question 5:
     * <pre>
     *     Group countries by its continent.
     * </pre>
     *
     * @param countryList
     * @return
     */
    public Map<Continent, List<Country>> groupByContinent(List<Country> countryList) {
        return null;
    }

    /**
     * Question 6:
     * <pre>
     *      Convert given country list to country name list.
     *      Caution: Use stream() and map().
     * </pre>
     *
     * @param countryList
     * @return
     */
    public List<String> convertToCountryNameList(List<Country> countryList) {
        return null;
    }

    /**
     * Question 7:
     * <pre>
     *     Subset given list following the condition that the area of the country is over 500,000.
     * </pre>
     *
     * @param countryList
     * @return
     */
    public List<Country> filterByArea(List<Country> countryList) {
        return null;
    }

    /**
     * Question 8:
     * <pre>
     *     Sum populations of all counties in given list.
     * </pre>
     *
     * @param countryList
     * @return
     */
    public long sumPopulation(List<Country> countryList) {
        return -1;
    }

    /**
     * Question 9:
     * <pre>
     *     Sum GDP of the country of which population is less than 100,000,000.
     * </pre>
     *
     * @param countryList
     * @return
     */
    public BigDecimal sumGdp(List<Country> countryList) {
        return null;
    }

    /**
     * Question 10:
     * <pre>
     *     Get max GDP among the countries for each continent.
     *     If any GDP is not present, set ZERO.
     * </pre>
     *
     * @param countryList
     * @return
     */
    public Map<Continent, BigDecimal> getMaxGdpForEachContinent(List<Country> countryList) {
        return null;
    }

}
