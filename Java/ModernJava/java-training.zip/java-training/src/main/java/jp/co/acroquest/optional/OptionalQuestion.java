package jp.co.acroquest.optional;

import java.util.Optional;

/**
 * Answer following questions.
 *
 * @see <a href="https://www.baeldung.com/java-optional">Baeldung.com - Guide To Java 8 Optional</a>
 */
public class OptionalQuestion {

    /**
     * Question 1:
     * <pre>
     *     Create empty Optional object.
     * </pre>
     *
     * @return
     */
    public Optional<Void> emptyOptional() {
        return null;
    }

    /**
     * Question 2:
     * <pre>
     *     Create Optional object with the argument. (the argument is not null).
     * </pre>
     *
     * @param s
     * @return
     */
    public Optional<String> optionalWithString(String s) {
        return null;
    }

    /**
     * Question 3:
     * <pre>
     *     Create Optional object by an argument.
     *     Caution: the argument may be null. This method must not throw any exceptions.
     * </pre>
     *
     * @param s
     * @return
     */
    public Optional<String> createOptionalByNullable(String s) {
        return null;
    }

    /**
     * Question 4:
     * <pre>
     *     Check given optional is present.
     * </pre>
     *
     * @param maybeString
     * @return
     */
    public boolean checkIfPresent(Optional<String> maybeString) {
        return false;
    }

    /**
     * Question 5:
     * <pre>
     *     Check given optional is empty.
     * </pre>
     *
     * @param maybeString
     * @return
     */
    public boolean checkIfEmpty(Optional<String> maybeString) {
        return false;
    }

    /**
     * Question 6:
     * <pre>
     *     If given optional object is present, return its value.
     *     If it is empty, return default value "Hello!".
     * </pre>
     *
     * @param maybeString
     * @return
     */
    public String orElseGet(Optional<String> maybeString) {
        return null;
    }

    /**
     * Question 7:
     * <pre>
     *     If given optional object is present, return its value.
     *     If it is empty, throw IllegalArgumentException("Argument must not be empty").
     * </pre>
     *
     * @param maybeString
     * @return
     */
    public String orElseThrow(Optional<String> maybeString) {
        return null;
    }

    /**
     * Question 8:
     * <pre>
     *     Return given optional if it contains a string that starts with "A", or else an empty optional.
     * </pre>
     *
     * @param maybeString
     * @return
     */
    public Optional<String> filterIfStringStartsWithA(Optional<String> maybeString) {
        return null;
    }

    /**
     * Question 9:
     * <pre>
     *     Convert the string in given optional to upper case.
     * </pre>
     *
     * @param maybeString
     * @return
     */
    public Optional<String> mapToUpperCase(Optional<String> maybeString) {
        return null;
    }

    /**
     * Question 10:
     * <pre>
     *     Get the score of mathematics of given student, (Wrap the score with Optional.)
     * </pre>
     *
     * @param student
     * @return
     */
    public Optional<Score> getScoreOfMathematics(Optional<Student> student) {
        return null;
    }

    /**
     * Question 11:
     * <pre>
     *     Convert student name to lower case if it stars with "S".
     *     If not, return "Unknown" as a fixed value.
     * </pre>
     *
     * @param student
     * @return
     */
    public String getNameLowerCaseIfStartsWithS(Optional<Student> student) {
        return null;
    }

    /**
     * Question 12:
     * <pre>
     *     Get the score value of science of the student
     *     if his/her score of history is more than 80.
     *     If not, throw RuntimeException.
     * </pre>
     *
     * @param student
     * @return
     */
    public int getScoreValueWithCondition(Optional<Student> student) {
        return -1;
    }

}
