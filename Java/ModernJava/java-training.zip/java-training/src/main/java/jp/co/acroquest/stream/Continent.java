package jp.co.acroquest.stream;

public enum Continent {
    ASIA,
    EUROPE,
    AFRICA,
    AMERICA,
    OCEANIA,
    ANTARCTICA
}
